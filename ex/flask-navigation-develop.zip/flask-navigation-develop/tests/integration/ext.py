from flask.ext.navigation import Navigation


nav = Navigation()
