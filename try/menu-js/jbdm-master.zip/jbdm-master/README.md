## JSON Bootsrap Dropdown-Menu

Check docs here [http://mityalebedev.github.io/jbdm/](http://mityalebedev.github.io/jbdm/ "JSON Bootsrap Dropdown-Menu").